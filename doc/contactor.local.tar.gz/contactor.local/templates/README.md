Templates for HTTP status, directory index and API introspaection
