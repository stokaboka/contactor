Application setup (first-run) logic
