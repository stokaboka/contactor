{
  // Databases including persistent session storage and application specific
/*
	impress: {
		url: "mongodb://127.0.0.1:27017/impress", // MongoDB connection string
		slowTime: "2s",                           // time to log query as slow
		collections: ["sessions", "users", "groups"],  // Collection name for store sessions (to be removed and use introspection)
		security: true                            // this database will be used for security subsystem storage (sessions, users, groups)
	},

	system: {
		url: "mysql://stokaboka_rdsdev:k0dtk2c1@rb-01.cgh9xag3iems.us-east-2.rds.amazonaws.com/rb_01_00?timezone=-0300", // MySQL connection example
	 	slowTime: 1000                                // time to log query as slow
	 },
*/

  // MySQL example database configuration
  //
  //  mysqlConnection: {
  //    // Connection string (required)
  //    url: 'mysql://impress:password@127.0.0.1/impress',
  //    // Time to log query as slow
  //    // (optional, default: '2s', in milliseconds or string like '5s')
  //    slowTime: 1000
  //  },

  // PgSQL example database configuration
  //
  //  pgsqlConnection: {
  //    // Connection string (required)
  //    url: 'postgres://impress:password@127.0.0.1/test',
  //    // Time to log query as slow
  //    // (optional, default: '2s', in milliseconds or string like '5s')
  //    slowTime: 1000
  //  },

  // MongoDB example database configuration
  //
  //  mongoConnection: {
  //    // Connection string (required)
  //    url: 'mongodb://127.0.0.1:27017/dbname',
  //    // Collection to be created automatically if not exists
  //    collections: ['collname1', 'collname2'],
  //    // Time to log query as slow
  //    // (optional, default: '2s', in milliseconds or string like '5s')
  //    slowTime: '2s'
  //  }

}
