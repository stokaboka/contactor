{
  // Application configuration

  slowTime: '1s',

  // preload application to memory at startup (default: false)
  // preload: true,

  // set HTTP header Access-Control-Allow-Origin (default: not set)
  // allowOrigin: '*'
}
