// Application specific configuration
// You can place js file in this directory with your own structure and it will be loaded as an application config section

{
/*
	agat_db_name: "system",
	agat_otm_db_name: "otm_agat",

	path: {
		xlsx: 'files/xlsx/'
	}
*/
};