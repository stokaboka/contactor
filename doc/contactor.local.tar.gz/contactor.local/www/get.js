(client, callback) => {
	callback();
}