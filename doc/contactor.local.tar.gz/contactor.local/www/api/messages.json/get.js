(client, callback) => {

	client.res.setHeader('Access-Control-Allow-Origin', '*');

	api.messages.get( client, callback );

	callback();

}