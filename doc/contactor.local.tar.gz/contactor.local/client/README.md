Folder for grunt, gulp, bower and other build tools
