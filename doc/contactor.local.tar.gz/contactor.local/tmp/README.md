Folder for temporary files
